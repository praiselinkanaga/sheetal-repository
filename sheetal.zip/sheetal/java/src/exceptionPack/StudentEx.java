package exceptionPack;
public interface  StudentEx
{
public void addstudent();
public void printstudent();
}

	