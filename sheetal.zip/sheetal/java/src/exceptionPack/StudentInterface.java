package exceptionPack;

public class StudentInterface implements StudentEx
{
	String id,name;
	public void addstudent()
	{
		id="S171113400064";
		name="atheeva";
		
	}
	public void printstudent()
	{
		System.out.println("student id is:"+id);
		System.out.println("student name is:"+name);
	}
	
	public static void main(String[] args)
	{
		StudentInterface stInte1 = new StudentInterface();
		stInte1.addstudent();
		stInte1.printstudent();
		StudentEx st = new StudentInterface();
		st.addstudent();
		st.printstudent();
		
		
	}

}

	