package exceptionPack;

public abstract class StudentExmp
{
public abstract void addstudent();
public abstract void printstudent();
void calculate()
{
	int a,b;
	a=10;
	b=15;

	System.out.println(a);
	System.out.println(b);
}

}
