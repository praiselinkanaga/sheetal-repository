package exceptionPack;

public class StudentImp1 extends StudentExmp
{
	String id,name;
	public void addstudent()
	{
		id="S171113400064";
		name="atheeva";
		
	}
	public void printstudent()
	{
		System.out.println("student id is:"+id);
		System.out.println("student name is:"+name);
	}
	
	public static void main(String[] args)
	{
		StudentImp1 stImp1 = new StudentImp1();
		stImp1.addstudent();
		stImp1.printstudent();
		StudentExmp st = new StudentImp1();
		st.addstudent();
		st.printstudent();
		st.calculate();
		
	}

}
