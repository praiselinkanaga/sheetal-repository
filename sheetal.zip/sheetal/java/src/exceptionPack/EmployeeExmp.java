package exceptionPack;
public class EmployeeExmp
{
	int id=10;
	String name="aarav";
	public static void main(String[] args) 
	{
		EmployeeExmp employeeExmp=new EmployeeExmp();
		employeeExmp.accept();
		
	}
	void accept()
	{
		try
		{
			int ar[]=new int[10];
			ar[0]=20;
			ar[1]=25;
			System.out.println(ar[0]);
		}
		catch(Exception e)
		{
			System.out.println("exception handeled");
		}
		finally
		{
			System.out.println(id);
			System.out.println(name);
			int a,b;
			a=10;
			b=20;
			b+=10;
			System.out.println(a);
			System.out.println(b);
		
		}
	}
}
