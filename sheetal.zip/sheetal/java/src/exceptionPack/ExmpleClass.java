package exceptionPack;
class manager
{
	int mId;
	String mName;
	void addManager()
	{
		mId=201;
		mName="aarav";
	}
	void displayManager()
	{
		System.out.println("manager id is:"+mId);
		System.out.println("manager name is:"+mName);
		
	}
}
class clerk extends manager
{
	int CId;
	String CName;
	void addClerk()
	{
		CId=10;
		CName="sumeeth";
	}
	void displayClerk()
	{
		System.out.println("clerk id is:"+CId);
		System.out.println("clerk name is :"+CName);
	}
	@Override 
	void addManager()
	{
		for(int i=65;i<=90;i++)
		{
			System.out.println((char)i);
		
		}
	}
}	
public class ExmpleClass
{
	public static void main(String[] args) 
	{
	clerk c = new clerk ();
	c.addManager();
	c.displayManager();
	c.addClerk();
	c.displayClerk();
	
	

	}

}
